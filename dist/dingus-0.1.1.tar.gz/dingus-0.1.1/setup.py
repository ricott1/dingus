# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['dingus', 'dingus.codec', 'dingus.network', 'dingus.types', 'dingus.urwid_tui']

package_data = \
{'': ['*']}

install_requires = \
['PyNaCl>=1.4.0,<2.0.0',
 'google>=3.0.0,<4.0.0',
 'protobuf>=3.19.1,<4.0.0',
 'pyaes>=1.6.1,<2.0.0',
 'pyperclip>=1.8.2,<2.0.0',
 'python-socketio[asyncio_client]>=5.5.0,<6.0.0',
 'requests>=2.26.0,<3.0.0',
 'urwid>=2.1.2,<3.0.0']

entry_points = \
{'console_scripts': ['dingus = dingus.__main__:start']}

setup_kwargs = {
    'name': 'dingus',
    'version': '0.1.1',
    'description': 'Command-line Lisk explorer',
    'long_description': None,
    'author': 'Alessandro Ricottone',
    'author_email': 'ricott2@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
