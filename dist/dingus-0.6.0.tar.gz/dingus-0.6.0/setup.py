# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['dingus',
 'dingus.application',
 'dingus.application.cloak',
 'dingus.application.cloak.commands',
 'dingus.application.cloak.cross_chain_commands',
 'dingus.application.cloak.events',
 'dingus.application.cloak.methods',
 'dingus.application.cloak.schemas',
 'dingus.application.interoperability',
 'dingus.application.interoperability.commands',
 'dingus.application.interoperability.cross_chain_commands',
 'dingus.application.interoperability.events',
 'dingus.application.interoperability.methods',
 'dingus.application.interoperability.schemas',
 'dingus.application.legacy',
 'dingus.application.legacy.commands',
 'dingus.application.legacy.events',
 'dingus.application.legacy.methods',
 'dingus.application.legacy.schemas',
 'dingus.application.pos',
 'dingus.application.pos.commands',
 'dingus.application.pos.cross_chain_commands',
 'dingus.application.pos.events',
 'dingus.application.pos.methods',
 'dingus.application.pos.schemas',
 'dingus.application.template',
 'dingus.application.template.commands',
 'dingus.application.template.cross_chain_commands',
 'dingus.application.template.events',
 'dingus.application.template.methods',
 'dingus.application.template.schemas',
 'dingus.application.token',
 'dingus.application.token.commands',
 'dingus.application.token.cross_chain_commands',
 'dingus.application.token.events',
 'dingus.application.token.methods',
 'dingus.application.token.schemas',
 'dingus.beta_prep',
 'dingus.codec',
 'dingus.crypto',
 'dingus.db',
 'dingus.network',
 'dingus.tree',
 'dingus.tree.eth-verkle_trie_eip',
 'dingus.types',
 'dingus.urwid_tui']

package_data = \
{'': ['*'], 'dingus.beta_prep': ['mainchain/*', 'sidechain/*']}

install_requires = \
['ECPy>=1.2.5,<2.0.0',
 'PyNaCl>=1.4.0,<2.0.0',
 'blspy>=1.0.15,<2.0.0',
 'google>=3.0.0,<4.0.0',
 'petlib>=0.0.45,<0.0.46',
 'protobuf>=3.19.1,<4.0.0',
 'pyaes>=1.6.1,<2.0.0',
 'pyperclip>=1.8.2,<2.0.0',
 'python-socketio[asyncio-client]>=5.5.0,<6.0.0',
 'requests>=2.26.0,<3.0.0',
 'urwid>=2.1.2,<3.0.0']

entry_points = \
{'console_scripts': ['compile-schemas = dingus.codec.utils:compile_schemas',
                     'dingus = dingus.__main__:start']}

setup_kwargs = {
    'name': 'dingus',
    'version': '0.6.0',
    'description': 'Command-line Lisk explorer',
    'long_description': 'None',
    'author': 'Alessandro Ricottone',
    'author_email': 'ricott2@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
