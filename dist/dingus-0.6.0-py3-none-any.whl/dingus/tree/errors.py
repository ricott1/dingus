class MissingNodeError(Exception):
    pass


class EmptyValueError(Exception):
    pass


class InvalidKeyError(Exception):
    pass


class InvalidDataError(Exception):
    pass
