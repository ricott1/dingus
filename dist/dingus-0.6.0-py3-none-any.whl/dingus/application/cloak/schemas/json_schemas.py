from dingus.constants import Length

openSwapParamsSchema = {
	"type": 'object',
	"required": ['qx', 'qy', 'tokenID', 'value', 'recipientAddress', 'timelock'],
	"properties": {
		"qx": {
			"dataType": 'bytes',
			"fieldNumber": 1,
		},
		"qy": {
			"dataType": 'bytes',
			"fieldNumber": 2,
		},
		"tokenID": {
			"dataType": 'bytes',
			"fieldNumber": 3,
		},
		"value": {
			"dataType": 'uint64',
			"fieldNumber": 4,
		},
		"recipientAddress": {
			"dataType": 'bytes',
			"fieldNumber": 5,
		},
		"timelock": {
			"dataType": 'uint32',
			"fieldNumber": 6,
		},
	},
}

closeSwapParamsSchema = {
	"type": 'object',
	"required": ['swapID', 'secretKey'],
	"properties": {
		"swapID": {
			"dataType": 'bytes',
			"fieldNumber": 1,
		},
		"secretKey": {
			"dataType": 'bytes',
			"fieldNumber": 2,
		},
	},
}
redeemSwapParamsSchema = {
	"type": 'object',
	"required": ['swapID'],
	"properties": {
		"swapID": {
			"dataType": 'bytes',
			"fieldNumber": 1,
		},
	},
}

if __name__ == "__main__":
    from dingus.codec.utils import json_schema_to_protobuf, compile_schema
    json_schemas = {
        "openSwap": openSwapParamsSchema,
        "closeSwap": closeSwapParamsSchema,
        "redeemSwap": redeemSwapParamsSchema,
    }
    for name, js in json_schemas.items():
        proto_schema = json_schema_to_protobuf(js, name)
        print(proto_schema)
        compile_schema(proto_schema, name)